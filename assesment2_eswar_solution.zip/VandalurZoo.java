package Zoo;
import org.animals.Lion;
import org.animals.Elephant;
import org.animals.Monkey;
public class VandalurZoo {
	public static void main(String[] args) {
		Lion l = new Lion();
		l.liondetails();
		l.vegetarian();
		l.canClimb();
		l.getSound();
		Elephant p = new Elephant();
		p.elephantdetails();
		p.vegetarian();
		p.canClimb();
		p.getSound();
		Monkey m = new Monkey();
		m.monkeydetails();
		m.vegetarian();
		m.canClimb();
		m.getSound();
	}
}
