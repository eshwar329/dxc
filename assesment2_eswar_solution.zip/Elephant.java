package org.animals;

public class Elephant {
	String colour ="Grey";
	float weight= (float) 4000;
	int age = 10; 
	public void vegetarian() {
		
		System.out.println("Elephant is Herbivorous");
	}
	public void canClimb() {
		System.out.println("Elephant can't climb ");
		
	}
	public void getSound() {
		System.out.println("Elephant sounds ");
		
	}
	public void elephantdetails() {
		System.out.println("      Elephant       ");
		System.out.println("Elephant Colour is:"+colour);
		System.out.println("Elephant Weight is:"+weight);
		System.out.println("Elephant Age in Kg's is:"+age);
	}
	
}

